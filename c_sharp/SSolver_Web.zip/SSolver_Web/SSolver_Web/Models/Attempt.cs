﻿using System.Collections.Generic;

namespace SSolver_Web.Models
{
    public class Attempt
    {
        public int AttemptNumber { get; }
        public List<Decision> Decisions { get; set; }

        public Attempt(int attemptNumber)
        {
            AttemptNumber = attemptNumber;
            Decisions = new List<Decision>();
        }
    }
}


