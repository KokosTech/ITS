﻿namespace SSolver_Web.Models.Sudoku
{
    public class Box
    {
        public int StartRow { get; set; }
        public int EndRow { get; set; }
        public int StartColumn { get; set; }
        public int EndColumn { get; set; }
    }
}